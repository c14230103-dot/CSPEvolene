module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/@supabase/supabase-js [external] (@supabase/supabase-js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@supabase/supabase-js", () => require("@supabase/supabase-js"));

module.exports = mod;
}),
"[project]/lib/supabaseClient.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/supabaseClient.js
__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$supabase$2f$supabase$2d$js__$5b$external$5d$__$2840$supabase$2f$supabase$2d$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@supabase/supabase-js [external] (@supabase/supabase-js, cjs)");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://xwkdvyhhilfgzeykxpmu.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3a2R2eWhoaWxmZ3pleWt4cG11Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ0MDUyMTksImV4cCI6MjA3OTk4MTIxOX0.x4W4stSkx5fL8-U0rDVqPqqaq-c5P0x2z-gMJUuCfIE");
const supabase = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$supabase$2f$supabase$2d$js__$5b$external$5d$__$2840$supabase$2f$supabase$2d$js$2c$__cjs$29$__["createClient"])(supabaseUrl, supabaseAnonKey);
}),
"[project]/pages/api/checkout.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// pages/api/checkout.js
__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseClient$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabaseClient.js [api] (ecmascript)");
;
async function handler(req, res) {
    if (req.method !== 'POST') {
        res.setHeader('Allow', [
            'POST'
        ]);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
    const { cart } = req.body;
    if (!cart || !Array.isArray(cart) || cart.length === 0) {
        return res.status(400).json({
            message: 'Keranjang kosong'
        });
    }
    const ids = cart.map((item)=>item.product.id);
    const { data: products, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseClient$2e$js__$5b$api$5d$__$28$ecmascript$29$__["supabase"].from('products').select('*').in('id', ids);
    if (error) return res.status(500).json({
        message: error.message
    });
    // Validasi stok
    for (const item of cart){
        const productInDb = products.find((p)=>p.id === item.product.id);
        if (!productInDb) {
            return res.status(400).json({
                message: `Produk ${item.product.name} tidak ditemukan`
            });
        }
        if (item.quantity > productInDb.stock) {
            return res.status(400).json({
                message: `Stok ${productInDb.name} tidak mencukupi (tersisa ${productInDb.stock})`
            });
        }
    }
    // Hitung total
    const total = cart.reduce((sum, item)=>sum + item.product.price * item.quantity, 0);
    // Update stok di database
    for (const item of cart){
        const productInDb = products.find((p)=>p.id === item.product.id);
        const newStock = productInDb.stock - item.quantity;
        const { error: updateError } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseClient$2e$js__$5b$api$5d$__$28$ecmascript$29$__["supabase"].from('products').update({
            stock: newStock
        }).eq('id', productInDb.id);
        if (updateError) {
            return res.status(500).json({
                message: updateError.message
            });
        }
    }
    // Simulasi penyimpanan order (opsional, tapi bagus untuk laporan)
    const randomBank = generateRandomBankAccount();
    const { data: userRes } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseClient$2e$js__$5b$api$5d$__$28$ecmascript$29$__["supabase"].auth.getUser();
    const userId = userRes?.user?.id || null;
    const { error: orderErr } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseClient$2e$js__$5b$api$5d$__$28$ecmascript$29$__["supabase"].from('orders').insert({
        user_id: userId,
        total_amount: total,
        bank_account: randomBank
    });
    if (orderErr) {
        // tidak fatal untuk simulasi, tapi tetap diinformasikan jika mau
        console.error(orderErr);
    }
    return res.status(200).json({
        success: true,
        total,
        bankAccount: randomBank
    });
}
function generateRandomBankAccount() {
    const bankNames = [
        'BCA',
        'BNI',
        'BRI',
        'Mandiri',
        'CIMB'
    ];
    const bank = bankNames[Math.floor(Math.random() * bankNames.length)];
    const number = Math.floor(Math.random() * 9000000000) + 1000000000; // 10 digit
    return `${bank} - ${number}`;
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__91999144._.js.map