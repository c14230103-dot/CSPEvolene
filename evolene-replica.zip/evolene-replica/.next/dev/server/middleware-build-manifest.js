globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
      "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
      "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
      "static/chunks/node_modules_67109ab5._.js",
      "static/chunks/[root-of-the-server]__2b92b491._.js",
      "static/chunks/pages_index_2da965e7._.js",
      "static/chunks/turbopack-pages_index_80b0482c._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_4025f6b7._.js",
      "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_next_link_207af988.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
      "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
      "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
      "static/chunks/node_modules_67109ab5._.js",
      "static/chunks/[root-of-the-server]__73a60baf._.js",
      "static/chunks/styles_globals_dc36e6c9.css",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_1e467ffc._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
      "static/chunks/node_modules_next_dist_shared_lib_cf5b50a6._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_19fd0646._.js",
      "static/chunks/node_modules_next_error_1cfbb379.js",
      "static/chunks/[next]_entry_page-loader_ts_43b523b5._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_7f09fef0._.js",
      "static/chunks/[root-of-the-server]__092393de._.js",
      "static/chunks/pages__error_2da965e7._.js",
      "static/chunks/turbopack-pages__error_9f8f7792._.js"
    ],
    "/admin": [
      "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_next_router_104fab1c.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
      "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
      "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
      "static/chunks/node_modules_67109ab5._.js",
      "static/chunks/[root-of-the-server]__a9048ba3._.js",
      "static/chunks/pages_admin_index_2da965e7.js",
      "static/chunks/turbopack-pages_admin_index_e67fc9fa.js"
    ],
    "/login": [
      "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_next_router_104fab1c.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
      "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
      "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
      "static/chunks/node_modules_67109ab5._.js",
      "static/chunks/[root-of-the-server]__a898b1df._.js",
      "static/chunks/pages_login_2da965e7._.js",
      "static/chunks/turbopack-pages_login_75e87e01._.js"
    ],
    "/signup": [
      "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_6024eba3._.js",
      "static/chunks/node_modules_next_router_104fab1c.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
      "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
      "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
      "static/chunks/node_modules_67109ab5._.js",
      "static/chunks/[root-of-the-server]__39fd380b._.js",
      "static/chunks/pages_signup_2da965e7._.js",
      "static/chunks/turbopack-pages_signup_d65e7da7._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];