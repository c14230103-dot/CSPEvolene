var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/checkout.js")
R.c("server/chunks/node_modules_next_dist_75df7829._.js")
R.c("server/chunks/[root-of-the-server]__91999144._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/checkout.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/checkout.js [api] (ecmascript)\" } [api] (ecmascript)").exports
