var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/products.js")
R.c("server/chunks/node_modules_next_dist_feadaa43._.js")
R.c("server/chunks/[root-of-the-server]__4e1be36f._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/products/index.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/products/index.js [api] (ecmascript)\" } [api] (ecmascript)").exports
