__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
  "static/chunks/node_modules_next_dist_shared_lib_4025f6b7._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_6024eba3._.js",
  "static/chunks/node_modules_next_link_207af988.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
  "static/chunks/node_modules_67109ab5._.js",
  "static/chunks/[root-of-the-server]__73a60baf._.js",
  "static/chunks/styles_globals_dc36e6c9.css",
  "static/chunks/pages__app_2da965e7._.js",
  "static/chunks/turbopack-pages__app_1e467ffc._.js"
])
