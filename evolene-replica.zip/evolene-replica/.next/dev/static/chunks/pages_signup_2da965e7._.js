(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
  "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_6024eba3._.js",
  "static/chunks/node_modules_next_router_104fab1c.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
  "static/chunks/node_modules_67109ab5._.js",
  "static/chunks/[root-of-the-server]__39fd380b._.js"
],
    source: "entry"
});
